##########################

Tresquintos
Bases de Datos de Tresquintos
Base: “Acusaciones Constitucionales en Chile, 1868-2020”
https://tresquintos.cl/datos

##########################

Variables 

id:
año:
función:
nombre:
partido:
tema:
dip_fdp: dd/mm/aaaa
dip_fdr: dd/mm/aaaa
dip_resolución:
sen_fdr: dd/mm/aaaa
sen_resolución: dd/mm/aaaa
resultado: resultado de la Acusación Constitucional

##########################

Fuentes:

[1]  Investigación

##########################

Citar:

Tresquintos.cl

##########################